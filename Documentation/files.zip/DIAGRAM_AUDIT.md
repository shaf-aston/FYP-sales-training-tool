# Diagram Audit & Consolidation Plan

## What Changed: 10 → 9 Diagrams

| Action | Files | Reason |
|--------|-------|--------|
| **Merged** | 06 + 07 → `06_class_diagram_combined.mmd` | Both class diagrams, heavily cross-referenced, no reason to be separate |
| **Rewrote** | `02_fsm_state_machine.mmd` | **Was definitively broken** — see below |
| **Slimmed** | `03_chat_turn_sequence.mmd` | 170 → 102 lines, removed bloated Note blocks |
| **Fixed** | `10_three_layer_control_architecture.mmd` | `<b>` HTML tags stripped, labels trimmed |
| **Kept** | 01, 04, 05, 08, 09 | Structurally correct, no changes needed |

---

## What Was Broken and Why

### 02_fsm_state_machine.mmd — BROKEN (would not render at all)

The diagram type was `stateDiagram-v2` but used `flowchart` node syntax for the terminal states:

```
%% ORIGINAL (broken) — flowchart syntax inside a stateDiagram:
SOLD_C["[SOLD]"]:::stageObj
WALKED_C["[WALKED]"]:::stageObj
```

These were floating at the bottom of the file, never properly defined as states.
The parser would reject the entire diagram.

**Fix:** Defined `SOLD_C` and `WALKED_C` as proper stateDiagram states *inside* their
respective sub-state blocks, then transition them to `[*]`:

```
state "SOLD" as SOLD_C
state "WALKED" as WALKED_C
C_OBJECTION --> SOLD_C : committed
C_OBJECTION --> WALKED_C : walkaway
SOLD_C   --> [*]
WALKED_C --> [*]
```

---

### 10_three_layer_control_architecture.mmd — May not render

Used raw `<b>...</b>` HTML tags inside node labels (22 instances).
Mermaid does not guarantee HTML rendering — depends entirely on the renderer.
GitHub renders it; mermaid.live may not; CLI rendering will strip it.

**Fix:** Removed all `<b>` tags, replaced with plain uppercase or colon-prefixed text.

---

### 03_chat_turn_sequence.mmd — Too verbose to be useful

At 170 lines with 7 node labels over 150 characters, the sequence diagram
was unreadable when rendered — it looked like a wall of text boxes.
The 3-layer annotations were buried inside a `fallback` alt block (wrong place).

**Fix:** Slimmed to 102 lines. Kept the HTTP flow structure, placed the three
layer notes correctly (Layer 1 at prompt assembly, Layer 3 after LLM response,
Layer 2 at advancement), removed all verbose code details.

---

## Remaining Issues to Address Manually

These are not broken but are dense and will look busy when rendered:

### 05_nlu_pipeline.mmd (202 lines — highest risk)

Seven single-line node labels over 180 characters. The NLU pipeline has lots
of inline code (`preceding[-1].lower() in _NEGATIONS` etc.) in node labels.

**Recommendation:** For any presentation use, consider splitting into two diagrams:
- `05a_intent_guardedness.mmd` — Intent classification + guardedness scoring
- `05b_objection_keyword_matching.mmd` — Objection classification + KW engine

### 06_class_diagram_combined.mmd (259 lines)

Large but should render fine — class diagrams handle lots of method signatures
naturally since each method is on its own line within the class box.
If it renders too tall, split back out into 06_core / 06_features.

### 08_session_lifecycle.mmd

Six node labels over 180 chars. These are all `<br/>`-separated multi-line nodes.
They render correctly but look dense. Could trim the inline code examples.

---

## Redundancy Remaining

After the merge, one area of genuine overlap remains:

**03 and 10 both cover the 3-layer architecture.**

This is intentional and acceptable — they serve different audiences:
- `10` = flowchart showing the decision logic (for understanding the concept)
- `03` = sequence diagram showing the HTTP request flow (for understanding the code)

No further merging needed here.

---

## Rendering Notes

- **Best renderer:** https://mermaid.live (paste any .mmd file directly)
- **GitHub:** renders all types automatically in .md files with backtick fences
- **VS Code:** install "Markdown Preview Mermaid Support"
- **CLI:** `mmdc -i file.mmd -o file.svg` (requires Chromium)

All diagrams use `%%{init: {"theme": "base"}}%%` which gives a clean white background
consistent across all renderers. Do not change to `"theme": "dark"` without testing
across all rendering targets first.
