/** Reusable text input component with configurable properties */
import React from "react";

const Input = ({
  type = "text",
  value,
  onChange,
  placeholder,
  disabled = false,
  className = "input-primary",
}) => {
  return (
    <input
      type={type}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      disabled={disabled}
      className={className}
    />
  );
};

export default Input;
