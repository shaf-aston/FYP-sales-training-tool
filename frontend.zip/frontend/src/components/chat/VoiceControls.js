/** Voice control buttons - microphone for speech-to-text and speaker toggle for auto-speak */
import React from "react";

const VoiceControls = ({
  isListening = false,
  isSpeaking = false,
  onStartListening,
  onStopListening,
  autoSpeak = false,
  onToggleAutoSpeak,
  disabled = false,
}) => {
  const handleMicClick = () => {
    if (isListening) {
      onStopListening?.();
    } else {
      onStartListening?.();
    }
  };

  return (
    <div className="voice-controls">
      <button
        className={`voice-button ${isListening ? "recording" : ""}`}
        onClick={handleMicClick}
        disabled={disabled}
        title={isListening ? "Stop listening" : "Start voice input"}
        type="button"
      >
        <span className="voice-icon">{isListening ? "🔴" : "🎤"}</span>
      </button>

      {onToggleAutoSpeak && (
        <button
          className={`voice-button speaker-toggle ${autoSpeak ? "active" : ""}`}
          onClick={onToggleAutoSpeak}
          disabled={disabled}
          title={autoSpeak ? "Disable auto-speak" : "Enable auto-speak"}
          type="button"
        >
          <span className="voice-icon">{autoSpeak ? "🔊" : "🔇"}</span>
          {isSpeaking && <span className="speaking-indicator"></span>}
        </button>
      )}
    </div>
  );
};

export default VoiceControls;
