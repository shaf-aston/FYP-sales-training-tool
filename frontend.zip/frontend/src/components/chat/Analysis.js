/** Displays session analysis data in formatted JSON view */
import React from "react";

const Analysis = ({ content, data }) => {
  return (
    <div className="analysis-card">
      <h4>{content}</h4>
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  );
};

export default Analysis;
