/** Chat inteface - individual chat messages */
import React from "react";
import DOMPurify from "dompurify";
import Analysis from "./Analysis";
import Feedback from "./Feedback";

const MessageBubble = ({ message }) => {
  const { type, content, feedback, data } = message;

  if (type === "analysis") {
    return <Analysis content={content} data={data} />;
  }

  const sanitizedContent = DOMPurify.sanitize(content, {
    ALLOWED_TAGS: ["b", "i", "em", "strong", "br"],
    ALLOWED_ATTR: [],
  });

  return (
    <div className={`message-bubble ${type}`}>
      <div
        className="message-content"
        dangerouslySetInnerHTML={{ __html: sanitizedContent }}
      />
      {feedback && <Feedback feedback={feedback} />}
    </div>
  );
};

export default MessageBubble;
