/** Progress tracker - displays captured information badges during training */
import React from "react";

const ChatProgress = ({ captures }) => {
  return (
    <div className="chat-progress">
      <div className="captures-display">
        {Object.entries(captures).map(
          ([key, value]) =>
            value && (
              <span key={key} className="capture-badge">
                {key}: ✓
              </span>
            )
        )}
      </div>
    </div>
  );
};

export default ChatProgress;
