/** Feedback display - renders quality rating, justification, and improvement suggestions */
import React from "react";

const Feedback = ({ feedback }) => {
  return (
    <div className="feedback-section">
      {feedback.quality && (
        <span
          className={`quality-badge quality-${feedback.quality.toLowerCase()}`}
        >
          {feedback.quality}
        </span>
      )}
      <p className="feedback-text">{feedback.justification}</p>
      {feedback.suggestions && feedback.suggestions.length > 0 && (
        <div className="suggestions-list">
          <strong>Suggestions:</strong>
          <ul>
            {feedback.suggestions.map((suggestion, i) => (
              <li key={i}>{suggestion}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Feedback;
