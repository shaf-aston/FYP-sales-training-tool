/** Chat header - displays scenario info, phase status, and session controls */
import React from "react";
import Button from "../common/Button";

const ChatHeader = ({ scenarioType, phase, onEndSession, onClose }) => {
  return (
    <div className="chat-header">
      <div className="chat-header-info">
        <h3>NEPQ Training - {scenarioType}</h3>
        <span className="phase-badge">Phase: {phase}</span>
      </div>
      <div className="chat-header-actions">
        <Button onClick={onEndSession} className="btn-secondary">
          End Session
        </Button>
        {onClose && (
          <Button onClick={onClose} className="btn-close">
            ×
          </Button>
        )}
      </div>
    </div>
  );
};

export default ChatHeader;
