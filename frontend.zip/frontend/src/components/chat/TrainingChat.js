/** Main chat interface - orchestrates sales-training session (rule-based) with message display, input, and voice features */
import React, { useRef, useEffect, useState } from "react";
import useChat from "../../hooks/useChat";
import useVoice from "../../hooks/useVoice";
import ChatHeader from "./ChatHeader";
import ChatProgress from "./ChatProgress";
import MessageBubble from "./MessageBubble";
import MessageInput from "./MessageInput";
import ErrorMessage from "../common/ErrorMessage";
import { DEFAULT_SCENARIO, TTS_MAX_CONTENT_LENGTH } from "../../constants";

const TrainingChat = ({ scenarioType = DEFAULT_SCENARIO, onClose }) => {
  const {
    messages,
    inputMessage,
    isLoading,
    phase,
    captures,
    error,
    handleInputChange,
    handleSendMessage,
    handleEndSession,
    clearError,
    setInputMessage,
  } = useChat(scenarioType);

  const {
    isListening,
    isSpeaking,
    error: voiceError,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    clearError: clearVoiceError,
  } = useVoice();

  const [autoSpeak, setAutoSpeak] = useState(true);
  const messagesEndRef = useRef(null);
  const previousMessagesLengthRef = useRef(0);

  // Single error source - voice errors are less critical, prioritize chat errors
  const displayError = error || voiceError;

  const handleClearError = () => {
    clearError();
    clearVoiceError();
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (!autoSpeak) return;

    if (messages.length > previousMessagesLengthRef.current) {
      const latestMessage = messages[messages.length - 1];

      if (
        latestMessage &&
        latestMessage.type === "assistant" &&
        latestMessage.content &&
        !isSpeaking &&
        !isListening
      ) {
        const sanitizedContent = latestMessage.content.trim().slice(0, TTS_MAX_CONTENT_LENGTH);
        speak(sanitizedContent).catch(() => {});
      }
    }

    previousMessagesLengthRef.current = messages.length;
  }, [messages, autoSpeak, speak, isSpeaking, isListening]);

  const handleStartListening = () => {
    startListening((text) => {
      setInputMessage((prev) => {
        // Append text with a space if there's existing content
        const prefix = prev && prev.trim().length > 0 ? prev + " " : "";
        return prefix + text;
      });
    });
  };

  const handleToggleAutoSpeak = () => {
    setAutoSpeak((prev) => {
      if (prev) stopSpeaking();
      return !prev;
    });
  };

  return (
    <div className="chat-interface">
      <ChatHeader
        scenarioType={scenarioType}
        phase={phase}
        onEndSession={handleEndSession}
        onClose={onClose}
      />

      <ErrorMessage message={displayError} onClear={handleClearError} />

      <ChatProgress captures={captures} />

      <div className="chat-messages">
        {messages &&
          messages.map((msg) => <MessageBubble key={msg.id} message={msg} />)}
        <div ref={messagesEndRef} />
      </div>

      <MessageInput
        value={inputMessage}
        onChange={handleInputChange}
        onSubmit={handleSendMessage}
        isLoading={isLoading}
        isListening={isListening}
        isSpeaking={isSpeaking}
        autoSpeak={autoSpeak}
        onStartListening={handleStartListening}
        onStopListening={stopListening}
        onToggleAutoSpeak={handleToggleAutoSpeak}
      />
    </div>
  );
};

export default TrainingChat;
