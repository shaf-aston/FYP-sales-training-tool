// Chat interface - input message
import React from "react";
import DOMPurify from "dompurify";
import Button from "../common/Button";
import VoiceControls from "./VoiceControls";

const MessageInput = ({
  value,
  onChange,
  onSubmit,
  isLoading,
  isListening,
  isSpeaking,
  autoSpeak,
  onStartListening,
  onStopListening,
  onToggleAutoSpeak,
}) => {
  const textareaRef = React.useRef(null);

  React.useEffect(() => {
    // Reset height when value is cleared or changed
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height =
        textareaRef.current.scrollHeight + "px";
    }
  }, [value]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (value.trim()) {
      const sanitized = DOMPurify.sanitize(value, {
        ALLOWED_TAGS: [],
        ALLOWED_ATTR: [],
      });
      if (sanitized.trim()) {
        onSubmit(e);
      }
    }
  };

  return (
    <form onSubmit={handleSubmit} className="chat-input-form">
      <textarea
        ref={textareaRef}
        value={value}
        onChange={onChange}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSubmit(e);
          }
        }}
        placeholder="Type your message..."
        aria-label="Chat message input"
        className="chat-input"
        disabled={isLoading}
        rows={1}
      />
      {onStartListening && (
        <VoiceControls
          isListening={isListening}
          isSpeaking={isSpeaking}
          autoSpeak={autoSpeak}
          onStartListening={onStartListening}
          onStopListening={onStopListening}
          onToggleAutoSpeak={onToggleAutoSpeak}
          disabled={isLoading}
        />
      )}
      <Button type="submit" className="btn-send" disabled={isLoading}>
        {isLoading ? "..." : "Send"}
      </Button>
    </form>
  );
};

export default MessageInput;
