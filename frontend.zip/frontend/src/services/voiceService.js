/** Voice service - manages browser Web Speech API for speech recognition and synthesis */
import { VOICE_CONFIG } from "../constants";

class VoiceService {
  constructor() {
    // Initialize browser speech synthesis
    this.synthesis = window.speechSynthesis;
    this.currentUtterance = null;
    this.isSpeaking = false;
    this.isListening = false;
    this.cachedVoices = null;
    this.silenceTimer = null;
    this.onStateChange = null;

    // Initialize speech recognition (with vendor prefixes)
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    this.recognitionAvailable = !!SpeechRecognition;

    if (this.recognitionAvailable) {
      this.recognition = new SpeechRecognition();
      this._configureRecognition();
    }

    // Pre-load voices
    this._loadVoices();
  }

  /**
   * Configure speech recognition with optimal settings
   * @private
   */
  _configureRecognition() {
    const config = VOICE_CONFIG.recognition;
    this.recognition.continuous = true; // Continuous for dictation
    this.recognition.interimResults = false; // Only final results
    this.recognition.lang = config.lang;
    this.recognition.maxAlternatives = 1;
  }

  /**
   * Pre-load voices to avoid delays
   * @private
   */
  _loadVoices() {
    if ("speechSynthesis" in window) {
      this.synthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        this.cachedVoices = this.synthesis.getVoices();
      };
    }
  }

  /**
   * Set callback for mic state changes (for UI updates)
   * @param {Function} callback - Called with boolean (true = listening, false = stopped)
   */
  setStateChangeCallback(callback) {
    this.onStateChange = callback;
  }

  /**
   * Update listening state and notify UI
   * @private
   */
  _setListeningState(listening) {
    this.isListening = listening;
    if (this.onStateChange) {
      this.onStateChange(listening);
    }
  }

  /**
   * TEXT-TO-SPEECH: Convert text to spoken audio
   * @param {string} text - Text to speak
   * @param {Object} options - Voice configuration overrides
   * @returns {Promise<void>}
   */
  async speak(text, options = {}) {
    if (!text || text.trim().length === 0) {
      return Promise.resolve();
    }

    this.stopSpeaking();

    return new Promise((resolve, reject) => {
      const utterance = new SpeechSynthesisUtterance(text);

      const config = { ...VOICE_CONFIG.synthesis, ...options };
      utterance.lang = config.lang;
      utterance.rate = config.rate;
      utterance.pitch = config.pitch;
      utterance.volume = config.volume;

      utterance.onend = () => {
        this.isSpeaking = false;
        this.currentUtterance = null;
        resolve();
      };

      utterance.onerror = (event) => {
        this.isSpeaking = false;
        this.currentUtterance = null;

        if (event.error === "interrupted" || event.error === "canceled") {
          resolve();
        } else {
          reject(new Error(`Speech synthesis failed: ${event.error}`));
        }
      };

      this.currentUtterance = utterance;
      this.isSpeaking = true;
      this.synthesis.speak(utterance);
    });
  }

  /**
   * Stop current speech synthesis
   */
  stopSpeaking() {
    if (this.synthesis.speaking) {
      this.synthesis.cancel();
    }
    this.isSpeaking = false;
    this.currentUtterance = null;
  }

  /**
   * SPEECH-TO-TEXT: Start continuous listening
   * Stays on indefinitely until manual stop or 10 seconds of silence
   * @param {Function} onResult - Callback for each final result
   * @param {Function} onError - Callback for errors
   * @returns {void}
   */
  startListening(onResult, onError) {
    if (!this.recognitionAvailable) {
      if (onError) onError(new Error("Speech recognition not available"));
      return;
    }

    // Prevent multiple simultaneous listening sessions
    if (this.isListening) {
      this.stopListening();
    }

    this._setListeningState(true);
    
    // Track last result to avoid duplicates
    let lastResultIndex = 0;
    let lastSpeechTime = Date.now();

    // Reset silence timer - triggers after 10 seconds of NO speech
    const resetSilenceTimer = () => {
      if (this.silenceTimer) clearTimeout(this.silenceTimer);
      lastSpeechTime = Date.now();
      
      this.silenceTimer = setTimeout(() => {
        // Only stop if truly 10 seconds have passed since last speech
        const timeSinceLastSpeech = Date.now() - lastSpeechTime;
        if (timeSinceLastSpeech >= 10000) {
          this.stopListening();
        }
      }, 10000);
    };

    this.recognition.onstart = () => {
      // Mic is now actively listening
      this._setListeningState(true);
      resetSilenceTimer();
    };

    this.recognition.onresult = (event) => {
      // User is speaking - reset the 10-second silence timer
      resetSilenceTimer();
      
      // Process only new results
      for (let i = lastResultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        
        if (result.isFinal) {
          const transcript = result[0].transcript.trim();
          lastResultIndex = i + 1;
          
          if (transcript && onResult) {
            onResult(transcript);
          }
        }
      }
    };

    this.recognition.onend = () => {
      // Check if we should keep listening or if user manually stopped
      if (this.isListening) {
        // Browser limitation: recognition auto-ends after ~60s
        // Restart it to continue listening
        try {
          this.recognition.start();
        } catch (error) {
          this._setListeningState(false);
          if (this.silenceTimer) clearTimeout(this.silenceTimer);
        }
      } else {
        // User manually stopped - update UI
        this._setListeningState(false);
      }
    };

    this.recognition.onerror = (event) => {
      const errorMessages = {
        'network': 'Network error - check internet connection',
        'not-allowed': 'Microphone access denied',
        'no-speech': 'No speech detected - continuing to listen',
        'audio-capture': 'No microphone found',
        'aborted': 'Speech recognition stopped',
      };
      
      const message = errorMessages[event.error] || `Error: ${event.error}`;
      
      // Handle "no-speech" gracefully - just keep listening
      if (event.error === 'no-speech') {
        // This is normal during pauses - don't stop, just restart
        if (this.isListening) {
          try {
            this.recognition.start();
            resetSilenceTimer();
          } catch (e) {
            // Ignore restart errors
          }
        }
      } else if (event.error === 'aborted') {
        // Manual stop - don't report as error
        this._setListeningState(false);
        if (this.silenceTimer) clearTimeout(this.silenceTimer);
      } else {
        // Real error - stop and report
        this._setListeningState(false);
        if (this.silenceTimer) clearTimeout(this.silenceTimer);
        if (onError) onError(new Error(message));
      }
    };

    try {
      this.recognition.start();
    } catch (error) {
      this._setListeningState(false);
      if (onError) onError(new Error("Failed to start speech recognition"));
    }
  }

  /**
   * Stop listening for voice input
   */
  stopListening() {
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }
    
    this._setListeningState(false);
    
    if (this.recognitionAvailable && this.recognition) {
      try {
        this.recognition.stop();
      } catch (error) {
        // Ignore errors on stop
      }
    }
  }

  /**
   * Get available voices for speech synthesis
   * @returns {Array<SpeechSynthesisVoice>}
   */
  getAvailableVoices() {
    if (this.cachedVoices && this.cachedVoices.length > 0) {
      return this.cachedVoices;
    }
    this.cachedVoices = this.synthesis.getVoices();
    return this.cachedVoices;
  }

  /**
   * Set preferred voice by name or language
   * @param {string} voiceName - Name or language code
   */
  setPreferredVoice(voiceName) {
    const voices = this.getAvailableVoices();
    const voice = voices.find(
      (v) => v.name === voiceName || v.lang.startsWith(voiceName)
    );

    if (voice && this.currentUtterance) {
      this.currentUtterance.voice = voice;
    }

    return voice;
  }

  /**
   * Check if voice features are available
   * @returns {Object} - Availability status
   */
  checkAvailability() {
    return {
      speechSynthesis: "speechSynthesis" in window,
      speechRecognition: this.recognitionAvailable,
      voices: this.getAvailableVoices().length,
    };
  }

  /**
   * Get status of voice services
   * @returns {Object}
   */
  getStatus() {
    return {
      available: true,
      speaking: this.isSpeaking,
      listening: this.isListening,
      recognition: this.recognitionAvailable,
      voicesLoaded: this.getAvailableVoices().length > 0,
    };
  }
}

// Singleton instance
const voiceService = new VoiceService();

export default voiceService;