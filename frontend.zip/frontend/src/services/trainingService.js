/** Training API service - handles all HTTP requests for session management and conversation */
import { API_BASE_URL, API_TIMEOUT, API_RETRY_COUNT, API_RETRY_BASE_DELAY, DEFAULT_PHASE } from "../constants";

class TrainingService {
  constructor() {
    this.baseURL = API_BASE_URL;
    this.timeout = API_TIMEOUT;
    this.retryCount = API_RETRY_COUNT;
    this.retryBaseDelay = API_RETRY_BASE_DELAY;

    // Bind methods to preserve context
    this.request = this.request.bind(this);
    this.startSession = this.startSession.bind(this);
    this.sendQuestion = this.sendQuestion.bind(this);
    this.getAnalysis = this.getAnalysis.bind(this);
    this.endSession = this.endSession.bind(this);
  }

  /**
   * Generic request handler with timeout, retries, and exponential backoff
   * @private
   */
  async request(endpoint, options = {}, retries = this.retryCount) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    let lastError;
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const response = await fetch(`${this.baseURL}${endpoint}`, {
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          ...options,
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          const error = await response
            .json()
            .catch(() => ({ detail: "Request failed" }));

          // Don't retry client errors (4xx)
          if (response.status >= 400 && response.status < 500) {
            throw new Error(error.detail || `HTTP ${response.status}`);
          }

          // Retry server errors (5xx)
          lastError = new Error(error.detail || `HTTP ${response.status}`);
          if (attempt < retries) {
            await this._delay(Math.pow(2, attempt) * this.retryBaseDelay);
            continue;
          }
          throw lastError;
        }

        return response.json();
      } catch (error) {
        clearTimeout(timeoutId);

        if (error.name === "AbortError") {
          throw new Error("Request timeout");
        }

        // Network errors: retry
        lastError = error;
        if (
          attempt < retries &&
          (error.message.includes("fetch") || error.message.includes("network"))
        ) {
          await this._delay(Math.pow(2, attempt) * this.retryBaseDelay);
          continue;
        }

        throw error;
      }
    }

    throw lastError;
  }

  /**
   * Delay helper for exponential backoff
   * @private
   */
  _delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Start a new training session
   * @param {string|null} customProfile - Optional custom profile
   * @returns {Promise<{conversation_id: string, response: string}>}
   */
  async startSession(customProfile = null) {
    // Use /chat endpoint with empty first message to initialize
    const response = await this.request("/chat", {
      method: "POST",
      body: JSON.stringify({
        conversation_id: null, // Backend generates new ID
        message: customProfile || "I want to start training",
      }),
    });

    return {
      session_id: response.conversation_id,
      initial_message: response.response,
    };
  }

  /**
   * Send user question to active session
   * @param {string} sessionId - Session ID
   * @param {string} question - User's question
   * @returns {Promise<{prospect_response: string, current_phase: string, captures: object, feedback?: object}>}
   */
  async sendQuestion(sessionId, question) {
    const response = await this.request("/chat", {
      method: "POST",
      body: JSON.stringify({
        conversation_id: sessionId,
        message: question,
      }),
    });

    // Adapt backend response to frontend expectations
    return {
      prospect_response: response.response,
      current_phase:
        response.nepq_stage || response.metadata?.current_phase || DEFAULT_PHASE,
      captures: response.metadata?.captures || {},
      feedback: response.metadata?.feedback,
      phase_gate_blocked: response.reason === "phase_gate_blocked",
      gate_message: response.message,
    };
  }

  /**
   * Get performance analysis for session
   * @param {string} sessionId - Session ID
   * @returns {Promise<object>}
   */
  getAnalysis(sessionId) {
    return this.request(`/conversation/${sessionId}/summary`);
  }

  /**
   * End training session
   * @param {string} sessionId - Session ID
   * @returns {Promise<{status: string}>}
   */
  endSession(sessionId) {
    return this.request(`/conversation/${sessionId}`, {
      method: "DELETE",
    });
  }
}

// Singleton instance
const trainingService = new TrainingService();
export default trainingService;
