/** Simple UUID generator for React keys - uses crypto.randomUUID for stable message IDs */

/**
 * Generates a unique identifier for React elements
 * Uses browser's crypto.randomUUID() if available, otherwise fallback to timestamp-based ID
 * @returns {string} Unique identifier
 */
export const generateUUID = () => {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }

  // Fallback for older browsers
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
};
