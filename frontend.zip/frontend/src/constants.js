/** Application-wide configuration constants for API endpoints and voice settings */

// API Configuration
export const API_BASE_URL =
  process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";
export const API_TIMEOUT = 30000; // 30 seconds
export const API_RETRY_COUNT = 3;
export const API_RETRY_BASE_DELAY = 1000; // 1 second base for exponential backoff

// Default Training Scenario
export const DEFAULT_SCENARIO = "fitness";
export const DEFAULT_PHASE = "intent";

// Voice Timeouts
export const VOICE_SILENCE_TIMEOUT = 10000; // 10 seconds before auto-stop
export const TTS_MAX_CONTENT_LENGTH = 1000; // Max chars for text-to-speech

// Voice Configuration
export const VOICE_CONFIG = {
  // Speech Recognition (STT)
  recognition: {
    continuous: false,
    interimResults: false,
    lang: "en-US",
    maxAlternatives: 1,
  },

  // Speech Synthesis (TTS)
  synthesis: {
    lang: "en-US",
    rate: 1.0,
    pitch: 1.0,
    volume: 1.0,
  },
};
