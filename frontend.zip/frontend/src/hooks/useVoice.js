/** Voice interaction hook - manages speech-to-text and text-to-speech states and controls */
import { useState, useCallback, useEffect } from "react";
import voiceService from "../services/voiceService";

const useVoice = () => {
  // STT State
  const [isListening, setIsListening] = useState(false);

  // TTS State
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Readiness State
  const [isReady, setIsReady] = useState(false);

  // Shared State
  const [error, setError] = useState(null);

  useEffect(() => {
    // Check for voice capabilities and set readiness
    const checkVoiceReady = async () => {
      try {
        await voiceService.checkAvailability();
        setIsReady(true);
      } catch (err) {
        setError(err.message || "Voice features not available");
        setIsReady(false);
      }
    };
    checkVoiceReady();
    // Sync isListening with actual mic state
    voiceService.setStateChangeCallback(setIsListening);
    return () => voiceService.setStateChangeCallback(null);
  }, []);

  /**
   * SPEECH-TO-TEXT: Start listening for user voice input
   */
  /**
   * SPEECH-TO-TEXT: Start listening for user voice input
   * @param {Function} onResult - Callback for receiving text
   */
  const startListening = useCallback((onResult) => {
    try {
      setError(null);
      setIsListening(true);

      voiceService.startListening(
        (text) => {
          if (onResult) onResult(text);
        },
        (err) => {
          setError(err.message);
          setIsListening(false);
        }
      );
    } catch (err) {
      setError(err.message || "Failed to recognize speech");
      setIsListening(false);
    }
  }, []);

  /**
   * Stop listening for voice input
   */
  const stopListening = useCallback(() => {
    voiceService.stopListening();
    setIsListening(false);
  }, []);

  /**
   * TEXT-TO-SPEECH: Speak text aloud
   * @param {string} text - Text to speak
   * @param {Object} options - Voice options (rate, pitch, volume)
   */
  const speak = useCallback(
    async (text, options = {}) => {
      if (!isReady) {
        // Silently fail if voice service isn't ready
        console.warn("Speak called before voice service was ready.");
        return;
      }
      try {
        setError(null);
        setIsSpeaking(true);

        await voiceService.speak(text, options);

        setIsSpeaking(false);
      } catch (err) {
        setIsSpeaking(false);
        throw err; // Re-throw to allow caller to handle
      }
    },
    [isReady]
  );

  /**
   * Stop current speech
   */
  const stopSpeaking = useCallback(() => {
    voiceService.stopSpeaking();
    setIsSpeaking(false);
  }, []);

  /**
   * Clear any errors
   */
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  /**
   * Check if voice features are available
   */
  const checkAvailability = useCallback(() => {
    return voiceService.checkAvailability();
  }, []);

  return {
    // STT
    isListening,
    startListening,
    stopListening,

    // TTS
    isSpeaking,
    speak,
    stopSpeaking,

    // Shared
    error,
    clearError,
    checkAvailability,
    isReady,
  };
};

export default useVoice;
