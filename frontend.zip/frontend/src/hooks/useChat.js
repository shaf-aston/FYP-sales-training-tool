/** Chat session hook - manages training conversation state, messages, and API interactions */
import { useState, useEffect, useRef } from "react";
import useApi from "./useApi";
import trainingService from "../services/trainingService";
import { generateUUID } from "../utils/uuid";
import { DEFAULT_PHASE } from "../constants";

const useChat = (scenarioType) => {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [sessionId, setSessionId] = useState(null);
  const [phase, setPhase] = useState(DEFAULT_PHASE);
  const [captures, setCaptures] = useState({});
  const [error, setError] = useState(null);

  // Track if session has been initialized to prevent re-runs
  const hasInitialized = useRef(false);

  const startSessionApi = useApi(trainingService.startSession);
  const sendQuestionApi = useApi(trainingService.sendQuestion);
  const getAnalysisApi = useApi(trainingService.getAnalysis);
  const endSessionApi = useApi(trainingService.endSession);

  const clearError = () => setError(null);

  // Initialize session ONCE on mount
  useEffect(() => {
    if (!scenarioType || hasInitialized.current) return;
    hasInitialized.current = true;

    const initSession = async () => {
      try {
        const response = await startSessionApi.request(scenarioType);
        setSessionId(response.session_id);
        setMessages([
          {
            id: generateUUID(),
            type: "system",
            content:
              response.initial_message ||
              "Session started. Ask your first question.",
          },
        ]);
      } catch {
        setError("Failed to start a new training session. Please try again.");
      }
    };

    initSession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scenarioType]); // Intentionally run once per scenarioType

  const handleInputChange = (e) => {
    setInputMessage(e.target.value);
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!inputMessage.trim() || !sessionId || sendQuestionApi.isLoading) return;

    const userMessage = inputMessage.trim();
    setInputMessage("");
    setMessages((prev) => [
      ...prev,
      { id: generateUUID(), type: "user", content: userMessage },
    ]);

    try {
      const response = await sendQuestionApi.request(sessionId, userMessage);

      // Add assistant message
      setMessages((prev) => [
        ...prev,
        {
          id: generateUUID(),
          type: "assistant",
          content: response.prospect_response.replace(
            /^\[Phase:.*?\]\s*-\s*/,
            ""
          ),
          feedback: response.feedback,
        },
      ]);

      // Show phase gate feedback if answer was insufficient
      if (response.phase_gate_blocked && response.gate_message) {
        setError(response.gate_message);
      }

      setPhase(response.current_phase);
      setCaptures(response.captures || {});
    } catch (err) {
      setError(
        "Failed to send message. Please check your connection and try again."
      );
    }
  };

  const handleEndSession = async () => {
    if (!sessionId) return;

    try {
      const analysis = await getAnalysisApi.request(sessionId);
      setMessages((prev) => [
        ...prev,
        {
          id: generateUUID(),
          type: "analysis",
          content: "Session Analysis",
          data: analysis,
        },
      ]);
      await endSessionApi.request(sessionId);
    } catch (err) {
      setError("Failed to retrieve session analysis. Please try again.");
      if (process.env.NODE_ENV === "development") {
        console.error("Failed to end session:", err);
      }
    }
  };

  return {
    messages,
    inputMessage,
    sessionId,
    isLoading:
      startSessionApi.isLoading ||
      sendQuestionApi.isLoading ||
      getAnalysisApi.isLoading ||
      endSessionApi.isLoading,
    phase,
    captures,
    error,
    handleInputChange,
    handleSendMessage,
    handleEndSession,
    clearError,
    setInputMessage,
  };
};

export default useChat;
