/** Learning scenarios configuration - centralized data for modules and personas
 * Modular design ensures easy updates without code changes
 * Follows Single Responsibility Principle: config file for scenario data only
 */

/**
 * Learning modules with NEPQ methodology across different industries
 */
export const learningModules = [
  {
    id: "fitness",
    title: "Fitness Learning",
    description: "Practice selling personal training services",
    difficulty: "Beginner",
    duration: "15-20 min",
  },
  {
    id: "business",
    title: "Business Opportunities",
    description:
      "Practice selling new business models (ecommerce, TikTok shops, AI agents, etc.)",
    difficulty: "Intermediate",
    duration: "20-25 min",
  },
];

/**
 * Roleplay personas with distinct personalities for practice scenarios
 */
export const roleplays = [
  {
    id: "skeptical",
    name: "The Skeptic",
    description: "A cautious buyer who needs solid proof before committing",
    traits: ["Analytical", "Cautious", "Detail-oriented"],
  },
  {
    id: "busy",
    name: "The Busy Executive",
    description: "Limited time, wants quick answers and clear value",
    traits: ["Time-conscious", "Direct", "Results-focused"],
  },
  {
    id: "friendly",
    name: "The Friendly Prospect",
    description: "Warm and open, but may struggle to make decisions",
    traits: ["Personable", "Indecisive", "Relationship-focused"],
  },
];
