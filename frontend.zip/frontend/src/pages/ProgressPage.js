import React from "react";
import "./Pages.css";

const skills = [
  { name: "Opening Questions", progress: 0 },
  { name: "Need Discovery", progress: 0 },
  { name: "Objection Handling", progress: 0 },
  { name: "Closing Techniques", progress: 0 },
  { name: "Rapport Building", progress: 0 },
];

const ProgressPage = () => (
  <div className="page-container">
    <div className="page-header">
      <h1>My Progress</h1>
      <p className="page-subtitle">Track your skill development journey.</p>
    </div>

    <div className="progress-section">
      <h2>Skills Progress</h2>
      <div className="skills-list">
        {skills.map((skill) => (
          <div key={skill.name} className="skill-item">
            <div className="skill-header">
              <span className="skill-name">{skill.name}</span>
              <span className="skill-percent">{skill.progress}%</span>
            </div>
            <div className="skill-bar">
              <div
                className="skill-fill"
                style={{ width: `${skill.progress}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>

    <div className="history-section">
      <h2>Recent Sessions</h2>
      <div className="empty-state">
        <p>No sessions completed yet. Start training to see your history.</p>
      </div>
    </div>
  </div>
);

export default ProgressPage;
