import React from "react";
import { Link } from "react-router-dom";
import "./Pages.css";

const DashboardPage = () => (
  <div className="page-container">
    <div className="page-header">
      <h1>Dashboard</h1>
      <p className="page-subtitle">
        Welcome back! Here's your training overview.
      </p>
    </div>

    <div className="stats-grid">
      <div className="stat-card">
        <span className="stat-value">0</span>
        <span className="stat-label">Sessions Completed</span>
      </div>
      <div className="stat-card">
        <span className="stat-value">0h</span>
        <span className="stat-label">Training Time</span>
      </div>
      <div className="stat-card">
        <span className="stat-value">0</span>
        <span className="stat-label">Skills Mastered</span>
      </div>
      <div className="stat-card">
        <span className="stat-value">--</span>
        <span className="stat-label">Avg. Score</span>
      </div>
    </div>

    <div className="quick-actions">
      <h2>Quick Actions</h2>
      <div className="action-cards">
        <Link to="/training" className="action-card">
          <span className="action-icon">📚</span>
          <span className="action-title">Start Training</span>
          <span className="action-desc">Begin a new training module</span>
        </Link>
        <Link to="/roleplays" className="action-card">
          <span className="action-icon">🎭</span>
          <span className="action-title">Practice Roleplay</span>
          <span className="action-desc">Practice with roleplay scenarios</span>
        </Link>
        <Link to="/progress" className="action-card">
          <span className="action-icon">📊</span>
          <span className="action-title">View Progress</span>
          <span className="action-desc">Track your improvement</span>
        </Link>
      </div>
    </div>
  </div>
);

export default DashboardPage;
