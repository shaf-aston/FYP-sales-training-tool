/** Chat page route - extracts scenario parameter and renders training chat interface */
import React from "react";
import { useParams } from "react-router-dom";
import TrainingChat from "../components/chat/TrainingChat";
import { DEFAULT_SCENARIO } from "../constants";

const ChatPage = () => {
  const { scenario } = useParams();

  return (
    <div className="chat-page">
      <TrainingChat scenarioType={scenario || DEFAULT_SCENARIO} />
    </div>
  );
};

export default ChatPage;
