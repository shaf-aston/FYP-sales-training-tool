import React from "react";
import { Link } from "react-router-dom";
import { roleplays } from "../config/scenarios";
import "./Pages.css";

const PracticePage = () => (
  <div className="page-container">
    <div className="page-header">
      <h1>Practice Scenarios</h1>
      <p className="page-subtitle">
        Practice with different prospect personalities.
      </p>
    </div>

    <div className="personas-grid">
      {roleplays.map((persona) => (
        <div key={persona.id} className="persona-card">
          <h3 className="persona-name">{persona.name}</h3>
          <p className="persona-desc">{persona.description}</p>
          <div className="persona-traits">
            {persona.traits.map((trait) => (
              <span key={trait} className="trait-tag">
                {trait}
              </span>
            ))}
          </div>
          <Link to={`/training/roleplay-${persona.id}`} className="btn-start">
            Start Roleplay
          </Link>
        </div>
      ))}
    </div>
  </div>
);

export default PracticePage;
