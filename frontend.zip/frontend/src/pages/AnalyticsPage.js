import React from "react";
import "./Pages.css";

const AnalyticsPage = () => (
  <div className="page-container">
    <div className="page-header">
      <h1>Analytics</h1>
      <p className="page-subtitle">Track your performance over time.</p>
    </div>

    <div className="analytics-placeholder">
      <div className="placeholder-icon">📈</div>
      <h2>No Data Yet</h2>
      <p>Complete training sessions to see your analytics here.</p>
    </div>

    <div className="metrics-preview">
      <h2>Metrics We Track</h2>
      <div className="metrics-grid">
        <div className="metric-item">
          <span className="metric-name">Question Quality</span>
          <span className="metric-info">How well you probe for needs</span>
        </div>
        <div className="metric-item">
          <span className="metric-name">Phase Progression</span>
          <span className="metric-info">Moving through NEPQ stages</span>
        </div>
        <div className="metric-item">
          <span className="metric-name">Response Time</span>
          <span className="metric-info">Speed of your replies</span>
        </div>
        <div className="metric-item">
          <span className="metric-name">Objection Handling</span>
          <span className="metric-info">Addressing prospect concerns</span>
        </div>
      </div>
    </div>
  </div>
);

export default AnalyticsPage;
