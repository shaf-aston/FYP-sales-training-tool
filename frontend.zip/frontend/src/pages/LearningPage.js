/** Learning page - centralized hub for training modules and theory */
import React from "react";
import { Link } from "react-router-dom";
import { learningModules } from "../config/scenarios";
import "./Pages.css";

const LearningPage = () => (
  <div className="page-container">
    <div className="home-hero">
      <h1 className="home-title">Sales Training Simulator</h1>
      <p className="home-subtitle">
        Learn and practice your sales skills with interactive modules
      </p>
    </div>

    <div className="page-header">
      <h2>Training Modules</h2>
      <p className="page-subtitle">
        Select a module to begin your learning session.
      </p>
    </div>

    <div className="modules-grid">
      {learningModules.map((module) => (
        <Link
          key={module.id}
          to={`/training/${module.id}`}
          className="module-card"
        >
          <h3 className="module-title">{module.title}</h3>
          <p className="module-desc">{module.description}</p>
          <div className="module-meta">
            <span className="module-difficulty">{module.difficulty}</span>
            <span className="module-duration">{module.duration}</span>
          </div>
        </Link>
      ))}
    </div>
  </div>
);

export default LearningPage;
