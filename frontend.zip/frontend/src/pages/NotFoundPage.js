/** 404 error page - displayed for invalid routes with 5-second countdown and auto-redirect
 * Features smooth animations for seamless user experience
 */
import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

const NotFoundPage = () => {
  const [countdown, setCountdown] = useState(5);
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate("/dashboard");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [navigate]);

  return (
    <div
      style={{
        textAlign: "center",
        padding: "3rem",
        minHeight: "70vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        animation: "fadeIn 0.5s ease-in",
      }}
    >
      <h1
        style={{
          fontSize: "6rem",
          marginBottom: "1rem",
          background:
            "linear-gradient(135deg, var(--text-accent) 0%, var(--success-color) 100%)",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
          animation: "slideDown 0.6s ease-out",
          fontWeight: "800",
        }}
      >
        404
      </h1>
      <h2
        style={{
          marginBottom: "1rem",
          fontSize: "1.8rem",
          color: "var(--text-light)",
          animation: "slideUp 0.7s ease-out",
        }}
      >
        Page Not Found
      </h2>
      <p
        style={{
          marginBottom: "2rem",
          color: "var(--text-muted)",
          fontSize: "1.1rem",
          animation: "fadeIn 0.8s ease-in",
        }}
      >
        The page you're looking for doesn't exist.
      </p>
      <p
        style={{
          marginBottom: "2rem",
          color: "var(--text-light)",
          fontSize: "0.95rem",
          animation: "pulse 1s ease-in-out infinite",
        }}
      >
        Redirecting to dashboard in{" "}
        <strong style={{ color: "var(--text-accent)" }}>{countdown}</strong>{" "}
        second
        {countdown !== 1 ? "s" : ""}...
      </p>
      <Link
        to="/dashboard"
        className="notfound-cta"
        style={{
          padding: "0.75rem 2rem",
          background:
            "linear-gradient(135deg, var(--text-accent) 0%, var(--success-color) 100%)",
          color: "#0f0f23",
          textDecoration: "none",
          borderRadius: "12px",
          fontWeight: "600",
          fontSize: "1rem",
          boxShadow: "var(--shadow-glow)",
          transition: "all 0.25s ease",
          animation: "scaleIn 0.5s ease-out",
        }}
      >
        Go to Dashboard Now
      </Link>
      <style>
        {`
          @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
          }
          @keyframes slideDown {
            from { 
              opacity: 0; 
              transform: translateY(-30px); 
            }
            to { 
              opacity: 1; 
              transform: translateY(0); 
            }
          }
          @keyframes slideUp {
            from { 
              opacity: 0; 
              transform: translateY(20px); 
            }
            to { 
              opacity: 1; 
              transform: translateY(0); 
            }
          }
          @keyframes scaleIn {
            from { 
              opacity: 0; 
              transform: scale(0.8); 
            }
            to { 
              opacity: 1; 
              transform: scale(1); 
            }
          }
          @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.6; }
          }
          .notfound-cta:hover {
            transform: translateY(-4px) scale(1.03);
            box-shadow: 0 10px 30px rgba(0, 255, 136, 0.25);
          }
          .notfound-cta:active {
            transform: translateY(0) scale(0.995);
          }
        `}
      </style>
    </div>
  );
};

export default NotFoundPage;
