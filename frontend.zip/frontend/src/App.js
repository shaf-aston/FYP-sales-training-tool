/** Main application component - configures routing and layout structure */
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/layout/Header";
import LearningPage from "./pages/LearningPage";
import ChatPage from "./pages/ChatPage";
import NotFoundPage from "./pages/NotFoundPage";
import DashboardPage from "./pages/DashboardPage";
import PracticePage from "./pages/PracticePage";
import AnalyticsPage from "./pages/AnalyticsPage";
import ProgressPage from "./pages/ProgressPage";

function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <Routes>
          <Route path="/learning" element={<LearningPage />} />
          <Route path="/training/:scenario" element={<ChatPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/roleplays" element={<PracticePage />} />
          <Route path="/analytics" element={<AnalyticsPage />} />
          <Route path="/progress" element={<ProgressPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
